
clear all

% load test1504.dat
load day3.dat

Fs = 1000;
A0 = 0.1;
Ka = 0.9;
sampling_rate = 200;

%figure(1)
% plot(test1504(:,1),test1504(:,3));
%plot(day3(:,1),day3(:,3));

title("Digital output in time domain");
% data(1,:) = test1504(:,3)';
data(1,:) = day3(:,3)';

% N = length(test1504); 
N = length(day3);

t = 1:1:N;
t = 1/N * t * 2*pi;   

%figure(2)
[YfreqDomain_output,frequencyRange_output] = centeredFFT(data,Fs);
%plot(frequencyRange_output,abs(YfreqDomain_output));
%title("Digital signal in frequency domain");


frequency = abs(YfreqDomain_output);
[maxfrequency_amplitute,index] = max(frequency(1,2*N/3:N));
best_frequency = (index + 2*N/3 -N/2)*Fs/N; %  


%figure(3)
fc = best_frequency;  
ys = square(2*pi*fc*t,50);
%plot(t,ys);
%title("Carrier square wave");

value = zeros(1,N);
i = 1;
for phy = 0:2*pi/N:2*pi
    ys_test = square(2*pi*fc*t + phy,50);
    y_combine = data.^ys_test;
    value(i) = mean(y_combine);
    i = i+1;
end

[max,p] = max(value);
ys = square(2*pi*fc*t + p*2*pi/N,50);


%figure(4);
sd = data.*ys*2 - A0;   
H_am = demod_filter;    
sd = filter(H_am,sd); 
[YfreqDomain_final,frequencyRange_final] = centeredFFT(sd,Fs);
% stem(frequencyRange_final,abs(YfreqDomain_final));
%stem(frequencyRange_final,abs(YfreqDomain_final));
title("De-modulated signal in frequency domain");

figure(5)
% plot(sd(1:4000),'o');
plot(sd,'o');
sd = sd+0.1;
title("De-modulated signal in frequency domain");


peak_count = 0;
threshold = mean(sd)+0.02;
for i = 2:N-1
    
    if (sd(1,i) > threshold)
        drev1 = sd(1,i) - sd(1,i-1);
        drev2 = sd(1,i) - sd(1,i+1);
        
        if (drev1 >= 0) && (drev2 >= 0)
            peak_count = peak_count + 1;
        end
        
    end
end
            
heartbeat = peak_count * 60 / (N/sampling_rate)/2;
% if ((heartbeat < 60) && (heartbeat >= 50)) 
%     heartbeat = heartbeat +20;
% else
%     if ((heartbeat < 66) && (heartbeat >= 60))
%         heartbeat = heartbeat +15;
%     else  ((heartbeat < 100) && (heartbeat >= 90))
%         heartbeat = heartbeat -10;
%     end
% end
fprintf('the value of heart rate is %.3f pulse per minute\n',heartbeat);









